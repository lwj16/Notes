function [Q, R, loss_hou, obj] = qr_householder(A)
    [n, m] = size(A);
    Q = eye(n); % 初始化 Q 为单位矩阵
    R = A;      % 初始化 R 为 A

    for k = 1:n-1
        % 提取当前列向量
        x = R(k:n, k);
        
        % 计算 Householder 反射向量
        e = zeros(size(x));
        e(1) = norm(x);
        v = x - e;
        v = v / norm(v); % 归一化
        
        % 构造 Householder 矩阵 H
        H = eye(n-k+1) - 2 * (v * v');
        
        % 扩展 H 到整个矩阵
        H_full = eye(n);
        H_full(k:n, k:n) = H;

        % 更新 R
        R = H_full * R;

        % 更新 Q
        Q = Q * H_full';
    end
    
    % 返回结果
    R = R(1:n, :); % 确保 R 是 n x n 矩阵
    obj = zeros(n);
    obj = Q' * Q - eye(n);
    loss_hou = norm(obj, 'fro');
end