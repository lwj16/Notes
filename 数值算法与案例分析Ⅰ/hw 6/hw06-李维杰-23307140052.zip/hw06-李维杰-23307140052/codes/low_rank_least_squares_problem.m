function x = low_rank_least_squares_problem(A,b)
   [m, n] = size(A);
   Q = zeros(m, n);
   R = zeros(n, n);
   target = zeros(n, 1);
   R_size = n;

   for i = 1:n
       % 列选主元
       tmp = norm(A(:, i), 2);
       target(i) = i;
       for j = i+1:n
           if norm(A(:, j), 2) > tmp
               tmp = norm(A(:, j), 2);
               target(i) = j;
           end
       end
       if target(i) ~= i
            A(:, [i, target(i)]) = A(:, [target(i), i]);
            R(:, [i, target(i)]) = R(:, [target(i), i]);
       end

        % mgs2
        % 计算 R(i,i) 的值
        R(i, i) = norm(A(:, i), 2);

        % 归一化 Q 的第 i 列
        if R(i, i) > 1e-6
            Q(:, i) = A(:, i) / R(i, i);
        else
            R_size = i - 1;
        end

        % 对之后的列进行正交化
        for j = i+1:n
            R(i, j) = Q(:, i)' * A(:, j); % 计算 R(i,j)
            A(:, j) = A(:, j) - R(i, j) * Q(:, i); % 正交化
        end
        
        % 对之前的列进行重正交化
        for j = 1:i-1
            R(i, j) = Q(:, i)' * Q(:, j); % 计算 R(i,j)
            Q(:, j) = Q(:, j) - R(i, j) * Q(:, i); % 正交化
        end
   end

   Q_T = Q';
   x_v = R(1:R_size, 1:R_size) \ (Q_T(1:R_size, :) * b);
    
   x = zeros(n, 1);
   x(1:R_size) = x_v(1:R_size);
   for i = R_size:-1:1
       if target(i) ~= i
           x([i, target(i)]) = x([target(i), i]);
       end
   end
end